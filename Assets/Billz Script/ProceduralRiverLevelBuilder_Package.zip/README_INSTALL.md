# Procedural River Level Builder (Unity 6)

Paket ini menambahkan procedural level generation untuk scene sungai. Generator membuat **jalur progres dari batu hookable saja**. Sampah hookable bersifat opsional dan tidak pernah menjadi syarat untuk mencapai FinishGoal.

## Isi paket

- `Assets/ProceduralRiver/Runtime/`: builder, validator, marker hook, loading UI, dan registrasi NetworkObject prefab.
- `Assets/ProceduralRiver/Resources/RiverObstacles/`: 12 prefab obstacle yang dikirim.
- `Assets/ProceduralRiver/Editor/`: menu instalasi scene.
- `Assets/ProceduralRiver/Runtime/RiverWorldSeedContext.cs`: mengubah room code host menjadi seed deterministik.
- `Assets/Scripts/...`: patch untuk `GameSpawner`, `PlayerMovement`, `LassoController`, `TrashObstacle`, serta `MainMenuController` agar room code menjadi seed multiplayer.

## Cara memasang

1. **Backup project dan scene terlebih dahulu.**
2. Ekstrak/merge folder `Assets` dari paket ini ke root project Unity. Saat diminta overwrite, izinkan overwrite untuk lima script yang ada di `Assets/Scripts`:
   - `GameManager/GameSpawner.cs`
   - `Player/PlayerMovement.cs`
   - `Player/LassoController.cs`
   - `Sampah/TrashObstacle.cs`
   - `UI/MainMenu/MainMenuController.cs`
3. Pastikan project memiliki package `Unity Splines`, `Netcode for GameObjects`, dan `TextMeshPro` (semuanya sudah dipakai script project sebelumnya).
4. Buka scene gameplay `In_Game_Raka`.
5. Di Unity Editor pilih **Tools > River Procedural > Install in Open Gameplay Scene**.
6. Menu tersebut memasang `RiverLevelBuilder` pada `RiverPath` valid, mengisi referensi `FinishGoal` dan `BoatController`, lalu menghapus root level design lama `LD_Zone1_Easy`, `LD_Zone2_Medium`, `LD_Zone3_Hard`, dan `LD_Zone4_Finale`.
7. Simpan scene setelah memeriksa perubahan.
8. Installer akan mencoba menambahkan tag `Batu` dan `Sampah` otomatis. Jika dialog instalasi masih melaporkan tag yang belum tersedia, tambahkan tag tersebut melalui **Project Settings > Tags and Layers**.

## Network prefab registration

`RiverNetworkPrefabRegistrar` melakukan bootstrap otomatis saat aplikasi mulai dan mendaftarkan tiga prefab `Sampah 1`, `Sampah 2`, dan `Sampah 3` ke `NetworkManager` sebelum tombol Host/Join digunakan. Ketiga prefab harus tersedia di semua build/peer dan harus tetap memiliki `NetworkObject` serta `TrashObstacle` pada root.

Di Console, cari log:

`[RiverPrefabRegistrar] Selesai...`

Jika log menyatakan `NetworkManager sudah mulai listening sebelum prefab sampah diregistrasikan`, berarti ada kode project yang memulai Host/Client terlalu dini. Dalam project yang dikirim, tombol Host/Join dipanggil dari UI setelah scene menu berjalan, sehingga bootstrap biasanya sudah sempat mendaftarkan prefab.

## Aturan generation

- Hookable Rock: di-spawn sepanjang spline sebagai anchor progres.
- Static Rock: obstacle kapal, tidak bisa di-hook.
- Hookable Trash: obstacle/interaksi opsional; membutuhkan beberapa tarikan sesuai `TrashObstacle` yang sudah ada.
- Static Trash: obstacle kapal, tidak bisa di-hook.
- Semua collider batu diberi Tag `Batu`; semua collider sampah diberi Tag `Sampah`.
- Jarak anchor disesuaikan terhadap `lassoRange` dan divalidasi kembali dari posisi pendekatan kapal ke anchor berikutnya.
- Jalur kapal memakai ukuran collider kapal yang diukur saat runtime. Obstacle opsional ditolak atau dicoba ulang bila memotong koridor kapal, bertumpuk, atau keluar dari batas sungai.
- Kepadatan obstacle menurun menjelang finish, dan ada `finishObstacleClearance` sebagai zona bebas obstacle.
- Semua peer membangun obstacle statis dari seed host yang sama. Hanya server yang melakukan `NetworkObject.Spawn()` untuk hookable trash.

## Seed untuk pengujian

Pada komponen `GameSpawner`, bagian **Debug - Reproducible World Seed**:

- `Use Fixed World Seed In Editor`: aktifkan untuk mengulang layout yang sama saat testing di Editor.
- `Fixed Editor World Seed`: masukkan seed yang ingin diuji.

Pengaturan ini dibaca oleh host/server; client tidak perlu mengatur nilainya karena menerima `WorldSeed` dari host. Matikan opsi ini saat build/release.

- **Multiplayer:** host mengubah room code menjadi seed deterministik (FNV-1a). Room code yang sama menghasilkan map yang sama; room code berbeda menghasilkan seed berbeda. Client tidak membuat seed sendiri, tetapi menerima `WorldSeed` yang direplikasi dari host.
- **Solo:** `MainMenuController` mengosongkan room-code context, sehingga `GameSpawner` membuat seed acak untuk setiap sesi Solo baru. Kembali ke Main Menu lalu memulai Solo lagi akan menghasilkan map baru.

## Debug dan validasi

Saat Play, pilih GameObject `River` yang memiliki `RiverLevelBuilder`. Gizmos menampilkan jalur kapal (hijau), jalur anchor batu (cyan), serta obstacle yang diterima (oranye). Builder menulis laporan lengkap ke Console, termasuk seed, panjang sungai, jumlah anchor, jarak hook, clearance badan kapal, batas sungai, overlap, dan hasil validasi.

Jika validasi gagal, match **tidak akan dipaksa mulai**. Loading/error overlay tetap terlihat, menampilkan tombol **RETURN TO MENU**, dan pemain belum dianggap siap. Periksa baris `FAILED` di laporan; jangan mengabaikannya karena itu menandakan layout belum lolos pemeriksaan.

## Parameter awal yang bisa di-tune

Di `RiverLevelBuilder`:

- `Anchor Spacing`: jarak longitudinal dasar antar batu hookable.
- `Anchor Lateral Offset`: offset batu dari centerline sungai.
- `Lasso Range`: samakan dengan `LassoController.lassoRange` (default 25).
- `Hook Safety Margin`: cadangan jarak untuk posisi pemain dan toleransi bidikan.
- `Static Rocks Per 100m`, `Static Trash Per 100m`, `Hookable Trash Per 100m`: density obstacle opsional.
- `Boat Clearance Margin`: ruang tambahan di luar footprint collider kapal.
- `Finish Obstacle Clearance`: jarak minimum obstacle dari FinishGoal.

Jika scene sungai dipendekkan, hitungan anchor dan obstacle otomatis mengikuti panjang spline. Pastikan `BoatController`, `FinishGoal`, serta spline river berada di scene aktif sebelum menekan Play.

## Catatan batas verifikasi

Paket ini telah diperiksa secara statis terhadap script dan prefab yang diberikan, tetapi tidak dapat dijalankan melalui Unity Editor/Player dari lingkungan pembuatan file ini. Setelah impor, lakukan Play Mode test untuk satu sesi Solo, dua client multiplayer, dan beberapa seed tetap sebelum build Android/WebGL.
