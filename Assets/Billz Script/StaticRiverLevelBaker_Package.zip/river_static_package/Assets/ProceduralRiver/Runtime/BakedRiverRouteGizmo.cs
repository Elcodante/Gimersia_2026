using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Edit-time visualization of the baked rock-only progression route.
/// Gizmos do not affect gameplay or runtime physics.
/// </summary>
[DisallowMultipleComponent]
public sealed class BakedRiverRouteGizmo : MonoBehaviour
{
    [SerializeField] private List<Vector3> routePoints = new List<Vector3>();
    [SerializeField] private List<Vector3> anchorPoints = new List<Vector3>();

    public void SetRoute(List<Vector3> route, List<Vector3> anchors)
    {
        routePoints = route != null ? new List<Vector3>(route) : new List<Vector3>();
        anchorPoints = anchors != null ? new List<Vector3>(anchors) : new List<Vector3>();
    }

    private void OnDrawGizmos()
    {
        if (routePoints == null || routePoints.Count < 2) return;

        Gizmos.color = new Color(0.1f, 1f, 0.35f, 0.95f);
        for (int i = 0; i < routePoints.Count - 1; i++)
            Gizmos.DrawLine(routePoints[i], routePoints[i + 1]);

        Gizmos.color = new Color(0.2f, 0.9f, 1f, 0.95f);
        if (anchorPoints != null)
        {
            for (int i = 0; i < anchorPoints.Count; i++)
                Gizmos.DrawSphere(anchorPoints[i], 0.8f);
        }

#if UNITY_EDITOR
        UnityEditor.Handles.color = Color.white;
        UnityEditor.Handles.Label(routePoints[0] + Vector3.up * 2f, "START");
        if (anchorPoints != null)
        {
            for (int i = 0; i < anchorPoints.Count; i++)
                UnityEditor.Handles.Label(anchorPoints[i] + Vector3.up * 2f, "ROCK " + (i + 1).ToString("00"));
        }
        UnityEditor.Handles.Label(routePoints[routePoints.Count - 1] + Vector3.up * 2f, "FINISH");
#endif
    }
}
