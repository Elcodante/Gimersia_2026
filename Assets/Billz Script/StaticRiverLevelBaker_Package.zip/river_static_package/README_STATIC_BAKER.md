# Static River Level Baker (Unity 6)

## Tujuan

Versi ini mengganti procedural generation saat runtime menjadi **scene baking di Edit Mode**.

- Generate dilakukan saat kamu sedang mengedit scene.
- Hasil generate menjadi prefab instances biasa yang tersimpan di `In_Game_Raka.unity`.
- Ketika game dijalankan, Unity tidak membuat ulang batu atau sampah.
- Semua pemain Solo maupun Multiplayer membaca layout scene yang sama.
- Seed hanya dipakai oleh Editor tool. Seed tidak mengubah map ketika game sedang dimainkan.

## Isi fitur

1. Jumlah anchor batu hookable menyesuaikan panjang spline sungai.
2. Jalur progres menggunakan batu hookable saja. Hookable trash selalu opsional.
3. Batu statis dan sampah statis tidak bisa di-hook, tetapi collider-nya diberi Tag `Batu` / `Sampah` agar tetap terdeteksi sebagai tabrakan kapal.
4. Hookable trash tetap memakai `NetworkObject` + `TrashObstacle`.
5. Hookable trash ditempatkan sebagai root-level scene objects, bukan child dari `Baked_RiverLevel`, agar aman sebagai NGO in-scene NetworkObjects.
6. Obstacle placement menghindari koridor kapal berdasarkan collider kapal dan ukuran collider prefab.
7. Densitas obstacle berkurang menjelang FinishGoal dan ada zona kosong sebelum finish.
8. Laporan menampilkan jarak Start → Anchor 1, jarak Boat Approach → Anchor berikutnya, koneksi ke finish, clearance kapal, batas sungai, dan perkiraan overlap.

> Validasi clearance memakai perkiraan bounds collider dan sampling spline. Ini bukan simulasi fisika lengkap. Tetap lakukan Play Mode test dengan kapal sebenarnya sebelum build.

## Instalasi

1. Backup project Unity dan scene `In_Game_Raka`.
2. Ekstrak ZIP ini ke root project Unity, lalu izinkan overwrite file yang ada.
3. File penting yang diperbarui:
   - `Assets/ProceduralRiver/Editor/RiverLevelBakerWindow.cs`
   - `Assets/ProceduralRiver/Editor/RiverLevelBuilderInstaller.cs` (menu installer runtime lama sekarang hanya menampilkan pemberitahuan)
   - `Assets/ProceduralRiver/Runtime/RiverNetworkPrefabRegistrar.cs` (tidak lagi mendaftarkan prefab secara runtime)
   - `Assets/ProceduralRiver/Runtime/HookableTarget.cs`
   - `Assets/Scripts/GameManager/GameSpawner.cs` (tidak menjalankan generation runtime, menunggu scene object NGO siap)
4. Tunggu Unity selesai compile.
5. Buka scene gameplay `In_Game_Raka`.

Prefab obstacle yang dibutuhkan harus tersedia di Project dengan nama persis:

- Hookable rock: `Batu hook 1`, `Batu hook 2`, `Batu Hook 3`
- Static rock: `Batu`, `BatuDatar`, `BatuPohon`
- Hookable trash: `Sampah 1`, `Sampah 2`, `Sampah 3`
- Static trash: `Sampah AH 1`, `Sampah AH 2`, `Sampah AH 3`

Tool mencari prefab berdasarkan nama asset di dalam folder `Assets`.

## Alur generate

1. Buka `Tools > River Level Baker > Open Static Level Baker`.
2. Klik `Auto Find References`.
3. Pastikan `River Path` menunjuk ke spline gameplay utama, bukan RiverPath helper/visual.
4. Pastikan `Finish Goal` menunjuk ke FinishGoal yang dipakai gameplay.
5. Pastikan `Boat Collider Source` menunjuk ke instance kapal di scene. Bila tidak ada instance kapal, drag prefab `Kapal` ke field tersebut agar ukuran collider bisa diukur.
6. Pilih Seed. Seed sama + parameter sama + prefab sama akan menghasilkan layout yang sama.
7. Klik `GENERATE / REPLACE LEVEL`.
8. Periksa root `Baked_RiverLevel_<seed>` di Hierarchy dan lihat hasilnya di Scene view. Garis hijau menunjukkan urutan START → batu anchor → FINISH; sphere cyan dan label ROCK menunjukkan anchor yang harus bisa di-hook. Pastikan tombol Gizmos di Scene view aktif.
9. Baca bagian `Last Generation Report`. Jika `REVIEW REQUIRED`, jangan abaikan penyebabnya. Periksa lebar sungai, posisi FinishGoal, ukuran collider, atau jarak anchor.
10. Jika sudah cocok, tekan `Ctrl+S` untuk menyimpan scene.

Gunakan `Regenerate With New Seed` untuk mendapatkan layout baru. Gunakan `Clear Baked Level` untuk menghapus hasil bake saat ini.

Jika scene masih mempunyai komponen generator runtime dari versi sebelumnya, jalankan `Tools > River Level Baker > Remove Runtime Generator Components`. Menu itu menghapus komponen `RiverLevelBuilder` / `RiverNetworkPrefabRegistrar` dari scene aktif, tetapi tidak menghapus hasil baked level.

## GameSpawner dan Multiplayer

`GameSpawner.cs` di paket ini mempertahankan handshake kesiapan pemain, tetapi tidak lagi mencari `RiverLevelBuilder` atau men-generate map.

Hookable trash memiliki `NetworkObject` dan merupakan **scene-placed NetworkObjects**. Kode `MainMenuController` pada project memuat gameplay scene memakai `NetworkManager.Singleton.SceneManager.LoadScene(...)`, sehingga objek scene dapat disinkronkan NGO kepada seluruh client.

Periksa `NetworkManager`:

- `Enable Scene Management` harus aktif.
- Gameplay scene harus dimuat lewat `NetworkManager.SceneManager`, bukan `UnityEngine.SceneManagement.SceneManager.LoadScene` saat sesi NGO aktif.
- Jangan tambahkan lagi `RiverNetworkPrefabRegistrar` lama. Asset prefab yang sudah ada di daftar NetworkPrefabs tidak perlu didaftarkan ulang oleh script runtime.

Pada runtime, `GameSpawner` menunggu sampai komponen `TrashObstacle` yang menjadi scene object selesai di-spawn oleh NGO. Jika ada error terkait TrashObstacle belum spawned, periksa Scene Management dan cara scene gameplay dimuat.

## Catatan penting tentang objek generated

- `Baked_RiverLevel_<seed>` berisi hookable rock dan obstacle statis.
- Hookable trash sengaja berada di root Hierarchy dengan nama `Baked_RiverLevel_NetworkTrash_...`, bukan di dalam root biasa. Ini disengaja agar NetworkObject tetap menjadi scene object NGO yang tidak diparent ke non-NetworkObject.
- Jangan hapus atau memindahkan hookable trash tersebut ke parent biasa.
- Scene yang sudah disimpan adalah layout final yang akan dibawa ke build.

## Saran pengujian sebelum build

1. Play Mode Solo: coba beberapa seed yang sudah di-bake, bukan generate ulang saat Play.
2. Pastikan setiap batu anchor bisa di-hook dan kapal bisa bergerak di sela obstacle.
3. Coba lepaskan hook lebih awal. Harus tetap ada anchor batu berikutnya; sampah tidak boleh diperlukan untuk progres.
4. Pastikan obstacle menipis menjelang FinishGoal.
5. Multiplayer dua client: pastikan kedua client melihat batu/sampah pada posisi yang sama dan hookable trash dapat ditarik oleh host/server.

Tidak ada loading screen generation di versi ini karena semua objek sudah ada di scene sebelum game dijalankan. Overlay `GameSpawner` yang tersisa hanya untuk menunggu kesiapan player/network session.
