# Patch Notes - Static River Level Baker

## Perubahan utama

- Generation dipindahkan sepenuhnya ke Unity Editor (`Tools > River Level Baker`).
- Layout yang dihasilkan disimpan sebagai prefab instances di scene; runtime tidak lagi melakukan random generation.
- Jalur progres hanya memakai hookable rocks. Hookable trash tetap opsional.
- Hookable trash tetap memakai `NetworkObject` dan `TrashObstacle`, lalu ditaruh sebagai scene-placed NetworkObjects di root Hierarchy.
- `RiverNetworkPrefabRegistrar` dibuat no-op untuk menghentikan registrasi prefab runtime yang menimbulkan duplicate GlobalObjectIdHash.
- `GameSpawner.PrepareLocalWorldRoutine` hanya menunggu scene-placed TrashObstacle dari NGO, lalu melanjutkan readiness handshake.
- Old runtime installer tidak lagi menambahkan `RiverLevelBuilder`.

## Catatan

Layout tidak berubah karena room code atau sesi baru. Untuk mengganti map, buka Editor Baker, pilih seed baru, Generate, lalu save scene.
