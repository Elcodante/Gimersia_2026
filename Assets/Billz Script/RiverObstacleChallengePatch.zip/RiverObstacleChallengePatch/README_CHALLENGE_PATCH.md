# River Obstacle Challenge Patch (Unity 6)

Patch ini hanya memperbarui generator static level dan visualisasi route di Editor. Tidak mengubah BoatController, LassoController, TrashObstacle, GameSpawner, prefab, NetworkManager, atau runtime spawning.

## Isi

- `Assets/ProceduralRiver/Editor/RiverLevelBakerWindow.cs`
  - Anchor main route memakai random-walk lateral, bukan pola kiri-kanan bergantian.
  - Jarak anchor memiliki jitter, tetap dibatasi agar hook range tidak dilanggar.
  - Membuat branch hookable-rock opsional yang menghubungkan dua anchor main berurutan.
  - Obstacle ditempatkan di berbagai lane sungai, bukan hanya menepi.
  - Static rock, static trash, dan hookable trash dikelompokkan menjadi obstacle fields.
  - Densitas default dinaikkan secara moderat.
  - Candidate placement ditolak bila estimasi cross-section kapal tidak menyisakan jalur yang cukup.
  - Finish fade dan clear zone tetap dipertahankan.
- `Assets/ProceduralRiver/Runtime/BakedRiverRouteGizmo.cs`
  - Main route: hijau.
  - Optional branch route: oranye.
  - Main anchor: cyan, label `ROCK`.
  - Optional branch anchor: kuning, label `ALT`.

## Instalasi

1. Backup project dan scene `In_Game_Raka`.
2. Ekstrak patch ke root project Unity dan izinkan overwrite hanya dua file `.cs` di atas.
3. Tunggu Unity selesai compile.
4. Buka `Tools > River Level Baker > Open Static Level Baker`.
5. Pilih seed yang sama untuk membandingkan hasil dengan layout lama, atau klik `New Seed` untuk hasil lain.
6. Klik `GENERATE / REPLACE LEVEL`.
7. Periksa main route hijau dan optional branches oranye di Scene View.
8. Periksa `Last Generation Report`, lalu test kapal di Play Mode sebelum menyimpan dan build.

## Parameter baru/berubah

- `Optional Branch Route Rate`: default 0.10. Sekitar 10% edge main route dicoba diberi jalur alternatif. Branch tidak wajib untuk finish.
- `Obstacle Field Spread`: default 8 m. Mengatur radius penyebaran obstacle dalam satu field.
- `Minimum Boat Passage Width`: default 2.5 m ruang bebas untuk posisi pusat kapal setelah footprint collider diperhitungkan.
- Default density: 2.4 static rocks, 2.5 static trash, dan 1.2 hookable trash per 100 m.

## Catatan validasi

Validasi jalur kapal memakai bounds collider yang diproyeksikan ke cross-section sungai dan sampel spline. Ini pendekatan konservatif, bukan simulasi sweep collider 3D yang lengkap. Jalankan Play Mode dan uji jalur kapal secara langsung, terutama di area obstacle fields dan cabang.

Hookable trash tetap opsional. Semua cabang yang ditambahkan hanya menggunakan hookable rocks; generator tidak pernah memasukkan sampah ke main route atau branch route.
